-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2015 at 11:52 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `subforumdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE IF NOT EXISTS `announcements` (
`postnum` int(11) NOT NULL,
  `username` varchar(18) CHARACTER SET utf8 NOT NULL,
  `subject` text CHARACTER SET utf8 NOT NULL,
  `date` varchar(30) CHARACTER SET utf8 NOT NULL,
  `message` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`postnum`, `username`, `subject`, `date`, `message`) VALUES
(1, 'Subrosian', 'Welcome to the forum!', 'Mar. 9/15, 12:40AM', 'Welcome to Subrosian''s home-made forum. Hope I get some activity around here!'),
(2, 'Jacob', 'Re: Welcome to the forum!', 'Jan. 31/15, 12:54PM', 'Really, please post!'),
(3, 'Subrosian', 'Re: New post!', 'Mar. 9/15, 12:27AM', 'Hi, this is a new post!'),
(4, 'Anonymous', 'Re: Re: New post!', 'Mar. 10/15, 3:47PM', 'Hi, I''m a reaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaally long announcement!');

-- --------------------------------------------------------

--
-- Table structure for table `gaming`
--

CREATE TABLE IF NOT EXISTS `gaming` (
`postnum` int(11) NOT NULL,
  `username` varchar(18) CHARACTER SET utf8 NOT NULL,
  `subject` text CHARACTER SET utf8 NOT NULL,
  `date` varchar(30) CHARACTER SET utf8 NOT NULL,
  `message` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `gaming`
--

INSERT INTO `gaming` (`postnum`, `username`, `subject`, `date`, `message`) VALUES
(1, 'Subrosian', 'So, about Super Smash Bros for Wii U', 'Jan. 31/15, 2:34PM', 'I haven''t gotten around to play that game very much. What''s your Wii U Friend code? Maybe anyone here can come around to play.'),
(2, 'Jacob', 'Re: So, about Super Smash Bros for Wii U', 'Jan. 31/15, 2:38PM', 'My friend code is 2391-594444-1192. What''s yours?');

-- --------------------------------------------------------

--
-- Table structure for table `general`
--

CREATE TABLE IF NOT EXISTS `general` (
`postnum` int(11) NOT NULL,
  `username` varchar(18) CHARACTER SET utf8 NOT NULL,
  `subject` text CHARACTER SET utf8 NOT NULL,
  `date` varchar(30) CHARACTER SET utf8 NOT NULL,
  `message` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `general`
--

INSERT INTO `general` (`postnum`, `username`, `subject`, `date`, `message`) VALUES
(1, 'Subrosian', 'Introduce yourself here!', 'Jan. 31/15, 1:20PM', 'So, my name is Subrosian Laguardia. I''m just some guy who enjoys dwelling basements.'),
(2, 'Jacob', 'Re: Introduce yourself here!', 'Mar. 10/15, 3:37PM', 'So, I''m Jacob Bell. I''m just an 18 year old freelancer from the Yukon who makes a living off of sculpting snow goons, and in his spare time likes to chill in the basement of his 150 sq. meter igloo.');

-- --------------------------------------------------------

--
-- Table structure for table `recent_posts`
--

CREATE TABLE IF NOT EXISTS `recent_posts` (
  `recency` int(11) NOT NULL COMMENT 'higher <=> more recent',
  `forum` varchar(100) NOT NULL,
  `postnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recent_posts`
--

INSERT INTO `recent_posts` (`recency`, `forum`, `postnum`) VALUES
(1, 'general', 2);

-- --------------------------------------------------------

--
-- Table structure for table `userdata`
--

CREATE TABLE IF NOT EXISTS `userdata` (
  `username` varchar(18) CHARACTER SET utf32 NOT NULL DEFAULT '',
  `password` varchar(18) NOT NULL,
  `avatar` varchar(300) CHARACTER SET utf32 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdata`
--

INSERT INTO `userdata` (`username`, `password`, `avatar`) VALUES
('Jacob', 'j', '/data/images/'),
('Subroman', '421', ''),
('Subrosian', 'k', 'asubrosian.png'),
('TestAcc4', '321', '');

-- --------------------------------------------------------

--
-- Table structure for table `userdata_lastreg`
--

CREATE TABLE IF NOT EXISTS `userdata_lastreg` (
  `username` varchar(18) NOT NULL,
  `id` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Just stores the last registered user, set upon a new registration.';

-- --------------------------------------------------------

--
-- Table structure for table `userdata_online`
--

CREATE TABLE IF NOT EXISTS `userdata_online` (
  `username` varchar(18) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
 ADD PRIMARY KEY (`postnum`), ADD UNIQUE KEY `postnum` (`postnum`);

--
-- Indexes for table `gaming`
--
ALTER TABLE `gaming`
 ADD PRIMARY KEY (`postnum`), ADD UNIQUE KEY `postnum` (`postnum`);

--
-- Indexes for table `general`
--
ALTER TABLE `general`
 ADD PRIMARY KEY (`postnum`), ADD UNIQUE KEY `postnum` (`postnum`);

--
-- Indexes for table `recent_posts`
--
ALTER TABLE `recent_posts`
 ADD PRIMARY KEY (`recency`);

--
-- Indexes for table `userdata`
--
ALTER TABLE `userdata`
 ADD PRIMARY KEY (`username`);

--
-- Indexes for table `userdata_lastreg`
--
ALTER TABLE `userdata_lastreg`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
MODIFY `postnum` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `gaming`
--
ALTER TABLE `gaming`
MODIFY `postnum` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `general`
--
ALTER TABLE `general`
MODIFY `postnum` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
